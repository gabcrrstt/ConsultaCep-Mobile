package com.example.webservice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity
    {
    private Button btnRecupera;
    private TextView txtResultado;
    private EditText edtcep;

    @Override
    protected void onCreate(Bundle savedInstanceState)
        {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRecupera = findViewById(R.id.btnRecupera);
        txtResultado = findViewById(R.id.txtResultado);
        edtcep        = findViewById(R.id.edtCEP);

        btnRecupera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
                {
                MyTask task = new MyTask();
                String urlApi = "https://viacep.com.br/ws/"+edtcep.getText().toString()+"/json/";

                edtcep.setText("");
                task.execute(urlApi);
                }
            });
        }


        public class MyTask extends AsyncTask<String, Void, String>
        {
            @Override
            protected String doInBackground(String... strings) {
                String stringUrl = strings[0];
                InputStream inputStream = null;
                InputStreamReader inputStreamReader = null;
                StringBuffer stringBuffer = new StringBuffer();

                try {
                    URL url = new URL(stringUrl);
                    HttpsURLConnection conexao = (HttpsURLConnection) url.openConnection();
                    inputStream = conexao.getInputStream();

                    inputStreamReader = new InputStreamReader(inputStream);

                    BufferedReader reader = new BufferedReader(inputStreamReader);
                    String linha = "";
                    while ( (linha = reader.readLine() ) != null)
                        {
                            stringBuffer.append(linha);
                        }
                    }
                catch (MalformedURLException e)
                    {
                        e.printStackTrace();
                    }
                catch (IOException e)
                    {
                        e.printStackTrace();;
                    }

                return stringBuffer.toString();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                String logradouro = null;
                String cep = null;
                String complemento = null;
                String bairro = null;
                String localidade = null;
                String uf = null;

                StringBuilder sb = new StringBuilder();
                //String objetoValor, valorMoeda, simbolo = null;
                try {
                    JSONObject jsonObject = new JSONObject(s);
                /*
                objetoValor = jsonObject.getString("BRL");
                JSONObject jsonObjectReal = new JSONObject(objetoValor);
                valorMoeda = jsonObjectReal.getString("last");
                simbolo = jsonObjectReal.getString("symbol");
                sb.append(simbolo).append("\n").append(valorMoeda).append("\n");
                */


                    logradouro = jsonObject.getString("logradouro");
                    cep = jsonObject.getString("cep");
                    complemento = jsonObject.getString("complemento");
                    bairro = jsonObject.getString("bairro");
                    localidade = jsonObject.getString("localidade");
                    uf = jsonObject.getString("uf");
                    sb.append(logradouro).append("\n").append(localidade).append("\n").append(cep)
                            .append("\n").append(complemento).
                            append("\n").append(bairro).append("\n").append(uf).append("\n");


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                txtResultado.setText(sb);
            }

        }
    }